package com.cleman.scheduleserviceapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScheduleServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
